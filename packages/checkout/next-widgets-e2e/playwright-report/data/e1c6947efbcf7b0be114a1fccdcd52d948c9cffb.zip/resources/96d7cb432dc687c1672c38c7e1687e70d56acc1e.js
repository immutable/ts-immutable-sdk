"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[654],{51662:function(e,t,a){let r;var i,n,s,o,d,l,c,u,p,_,h,g,E,m,R=a(42756),C=a(66883),f=a(86444),y=a(62788),w=a(95791),T=a(61296),O=a(75683),A=a(31277),v=a(3771),I=a(8951),N=a(17358),k=a(31923),S=(a(86357),a(50362)),L=a(84364),D=a(21019),b=a(66630),x=a(52069),U=a(2410),M=a(57473),P=a(72682),F=a(1647),H=a(2541),V=a(714),$=a(1971),G=a(58569),Z=a(6408),B=a(36843),W=a(51403),K=a(5973),z=a(77580);(i=c||(c={})).AUTHENTICATION_ERROR="AUTHENTICATION_ERROR",i.INVALID_CONFIGURATION="INVALID_CONFIGURATION",i.WALLET_CONNECTION_ERROR="WALLET_CONNECTION_ERROR",i.NOT_LOGGED_IN_ERROR="NOT_LOGGED_IN_ERROR",i.SILENT_LOGIN_ERROR="SILENT_LOGIN_ERROR",i.REFRESH_TOKEN_ERROR="REFRESH_TOKEN_ERROR",i.USER_REGISTRATION_ERROR="USER_REGISTRATION_ERROR",i.USER_NOT_REGISTERED_ERROR="USER_NOT_REGISTERED_ERROR",i.LOGOUT_ERROR="LOGOUT_ERROR",i.TRANSFER_ERROR="TRANSFER_ERROR",i.CREATE_ORDER_ERROR="CREATE_ORDER_ERROR",i.CANCEL_ORDER_ERROR="CANCEL_ORDER_ERROR",i.EXCHANGE_TRANSFER_ERROR="EXCHANGE_TRANSFER_ERROR",i.CREATE_TRADE_ERROR="CREATE_TRADE_ERROR",i.OPERATION_NOT_SUPPORTED_ERROR="OPERATION_NOT_SUPPORTED_ERROR",i.LINK_WALLET_ALREADY_LINKED_ERROR="LINK_WALLET_ALREADY_LINKED_ERROR",i.LINK_WALLET_MAX_WALLETS_LINKED_ERROR="LINK_WALLET_MAX_WALLETS_LINKED_ERROR",i.LINK_WALLET_VALIDATION_ERROR="LINK_WALLET_VALIDATION_ERROR",i.LINK_WALLET_DUPLICATE_NONCE_ERROR="LINK_WALLET_DUPLICATE_NONCE_ERROR",i.LINK_WALLET_GENERIC_ERROR="LINK_WALLET_GENERIC_ERROR";class X extends Error{type;constructor(e,t){super(e),this.type=t}}let q=async(e,t)=>{try{return await e()}catch(e){var a;throw new X((0,R.IZ)(e)&&e.response?.data&&"code"in(a=e.response.data)&&"message"in a?e.response.data.message:e.message,t)}},j="pkce_state",Q="pkce_verifier";class J{areValid(e){if(e){let t=this.isTokenValid(e.access_token),a=this.isTokenValid(e.id_token);return t&&a}return!1}isTokenValid(e){try{let t=(0,A.Z)(e).exp??0,a=Date.now()/1e3+3600;return t>a}catch(e){return!1}}savePKCEData(e){localStorage.setItem(j,e.state),localStorage.setItem(Q,e.verifier)}getPKCEData(){let e=localStorage.getItem(j),t=localStorage.getItem(Q);return e&&t?{state:e,verifier:t}:null}}var Y={warn:(...e)=>{void 0!==z&&z?.env?.JEST_WORKER_ID===void 0&&console.warn(...e)}};(n=u||(u={})).LOGGED_OUT="loggedOut",n.LOGGED_IN="loggedIn",n.ACCOUNTS_REQUESTED="accountsRequested";let ee=e=>!!e.zkEvm,et=e=>!!e.imx,ea="passport-overlay",er=`${ea}-close`,ei=`${ea}-try-again`,en=`
  <svg
    viewBox="0 0 20 20"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    style="width: 20px !important;"
    >
      <path
        d="M16.25 5.75833L14.2417 3.75L10 7.99167L5.75833 3.75L3.75 5.75833L7.99167 10L3.75 14.2417L5.75833 16.25L10 12.0083L14.2417 16.25L16.25 14.2417L12.0083 10L16.25 5.75833Z"
        fill="#F3F3F3"
      />
  </svg>
`,es=`
  <svg
  viewBox="0 0 17 16"
  fill="none"
  xmlns="http://www.w3.org/2000/svg"
  style="width: 16px !important;"
  >
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M0.5 14.3333L8.5 0.333336L16.5 14.3333H0.5ZM9.16667 10.6667V12H7.83333V10.6667H9.16667ZM9.16667 5.33334L9.16667 9.33334H7.83333L7.83333 5.33334H9.16667Z"
      fill="#E01A3D"
    />
  </svg>
`,eo=`
  <svg
    style="
      max-width: 123px !important;
      margin-bottom: 24px !important;
    "
    viewBox="0 0 124 112"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <g clip-path="url(#clip0_332_47939)">
      <g clip-path="url(#clip1_332_47939)">
        <path
          d="M4.10008 74.9453H0.5V93.6041H4.10008V74.9453Z"
          fill="#F3F3F3"
        />
        <path
          d="M22.9585 80.0212C21.1727 80.0212 19.5283 80.7622 18.5505 82.3115C17.8209 80.8013 16.3595 80.0212 14.4691 80.0212C12.864 80.0212 11.3786 80.7231 10.4792 82.1681V80.282H7.00976V93.6063H10.4792V86.2032C10.4792 84.3432 11.7445 82.9503 13.3475 82.9503H13.5565C14.9787 82.9503 15.643 83.8477 15.643 85.6187V93.6085H19.1124V86.2054C19.1124 84.3453 20.3647 82.9525 21.9676 82.9525H22.1767C23.5989 82.9525 24.237 83.8499 24.237 85.6208V93.6106H27.7064V85.2188C27.7064 83.6435 27.3274 82.3832 26.5717 81.4315C25.8029 80.4949 24.6029 80.0256 22.9585 80.0256V80.0212Z"
          fill="#F3F3F3"
        />
        <path
          d="M46.0291 80.0212C44.2432 80.0212 42.5989 80.7622 41.621 82.3115C40.8914 80.8013 39.43 80.0212 37.5396 80.0212C35.9345 80.0212 34.4492 80.7231 33.5497 82.1681V80.282H30.0803V93.6063H33.5497V86.2032C33.5497 84.3432 34.8151 82.9503 36.418 82.9503H36.6271C38.0493 82.9503 38.7135 83.8477 38.7135 85.6187V93.6085H42.1829V86.2054C42.1829 84.3453 43.4352 82.9525 45.0381 82.9525H45.2472C46.6694 82.9525 47.3075 83.8499 47.3075 85.6208V93.6106H50.7769V85.2188C50.7769 83.6435 50.398 82.3832 49.6422 81.4315C48.8734 80.4949 47.6734 80.0256 46.0291 80.0256V80.0212Z"
          fill="#F3F3F3"
        />
        <path
          d="M72.3077 89.2061V83.0785H75.2936V80.282H72.3077V75.9622H68.8383V80.282H61.4312V87.6851C61.4312 89.5451 60.192 91.0683 58.6805 91.0683H58.4715C57.2061 91.0683 56.4896 90.1318 56.4896 88.413V80.282H53.0202V88.8041C53.0202 90.3534 53.3991 91.5746 54.1549 92.4872C54.8975 93.4107 56.0322 93.867 57.5328 93.867C59.188 93.867 60.6102 93.0218 61.4312 91.655V93.6063H64.9006V83.0807H68.8405V90.1448C68.8405 92.396 70.0536 93.6063 72.3099 93.6063H75.7009V90.6794H73.7843C72.5582 90.6794 72.3099 90.4317 72.3099 89.2083L72.3077 89.2061Z"
          fill="#F3F3F3"
        />
        <path
          d="M88.0757 84.8082C88.0757 81.7378 85.8325 80.0191 82.4676 80.0191C79.1027 80.0191 77.0033 81.8791 76.7158 84.404H80.1982C80.2766 83.5979 81.0977 82.8156 82.35 82.8156H82.5722C83.8506 82.8156 84.7109 83.7391 84.7109 84.9364V85.2623L81.346 85.5622C79.9108 85.6795 78.7369 86.0945 77.8243 86.8246C76.9118 87.5525 76.4544 88.5934 76.4544 89.9471C76.4152 92.2895 78.4363 93.8888 80.8364 93.8627C82.5438 93.8627 83.9529 93.1348 84.7871 91.9766C84.8132 92.6785 84.8655 93.226 84.9439 93.6019H88.2042C88.1127 92.9783 88.0735 92.0005 88.0735 90.675V84.806L88.0757 84.8082ZM84.7109 88.1653C84.7109 89.8428 83.3148 91.0661 81.738 91.0661H81.5289C80.5772 91.0661 79.8737 90.5316 79.8737 89.7124C79.8737 89.204 80.0697 88.8281 80.4596 88.5543C80.8516 88.2805 81.3068 88.124 81.8164 88.0849L84.7109 87.785V88.1653Z"
          fill="#F3F3F3"
        />
        <path
          d="M97.7935 80.0212C96.0076 80.0212 94.5201 81.036 93.9452 82.0116V74.9475H90.4758V93.6063H93.9452V91.8766C94.5201 92.8523 96.0055 93.867 97.7935 93.867C101.537 93.9322 103.765 90.5881 103.726 86.9441C103.765 83.3002 101.535 79.956 97.7935 80.0212ZM97.2055 91.0683H96.9964C95.4044 91.1074 93.919 89.3908 93.9452 86.9441C93.919 84.4974 95.4065 82.7808 96.9964 82.8199H97.2055C98.9522 82.8199 100.257 84.4192 100.257 86.9181C100.257 89.4169 98.9391 91.0683 97.2055 91.0683Z"
          fill="#F3F3F3"
        />
        <path
          d="M108.931 74.9453H105.462V93.6041H108.931V74.9453Z"
          fill="#F3F3F3"
        />
        <path
          d="M117.057 80.0212C113.146 79.9691 110.667 82.9612 110.706 86.9441C110.641 91.1987 113.705 93.9192 117.057 93.867C120.33 93.867 122.443 92.0461 123.094 89.3908H119.651C119.403 90.3665 118.555 91.0683 117.303 91.0683H117.081C115.633 91.0683 114.2 89.8189 114.069 88.0371H123.094C123.133 87.4656 123.147 87.0484 123.147 86.7877C123.186 82.8982 120.956 79.9821 117.057 80.0212ZM114.071 85.3688C114.15 83.7934 115.363 82.8178 116.824 82.8178H117.033C118.495 82.8178 119.708 83.7934 119.784 85.3688H114.071Z"
          fill="#F3F3F3"
        />
      </g>
      <path
        d="M30.4851 101.025V109H32.0581V106.195H33.2571C35.0941 106.195 36.7221 105.7 36.7221 103.665C36.7221 101.256 34.8521 101.025 33.2131 101.025H30.4851ZM33.2461 102.257C34.1041 102.257 35.1051 102.367 35.1051 103.676C35.1051 104.732 34.3351 104.974 33.3561 104.974H32.0581V102.257H33.2461Z"
        fill="#F3F3F3"
      />
      <path
        d="M36.9683 109H38.5743L39.1353 107.383H42.2373L42.7983 109H44.5034L41.5224 101.025H39.9383L36.9683 109ZM40.6863 102.95L41.7863 106.096H39.5863L40.6863 102.95Z"
        fill="#F3F3F3"
      />
      <path
        d="M49.1875 105.689C50.0345 105.843 50.6615 106.096 50.6615 106.778C50.6615 107.636 49.7705 107.889 49.0665 107.889C48.1205 107.889 47.3065 107.537 47.1305 106.371H45.6125C45.7555 108.087 47.0535 109.143 49.0115 109.143C50.6175 109.143 52.2455 108.34 52.2455 106.701C52.2455 105.051 50.8155 104.534 49.5175 104.303L48.4725 104.116C47.8345 103.995 47.3615 103.687 47.3615 103.126C47.3615 102.411 48.1755 102.136 48.9015 102.136C49.6495 102.136 50.4635 102.444 50.5845 103.379H52.1025C52.0255 101.85 50.6175 100.882 48.9675 100.882C47.4935 100.882 45.7885 101.586 45.7885 103.192C45.7885 104.578 46.8775 105.249 48.1755 105.502L49.1875 105.689Z"
        fill="#F3F3F3"
      />
      <path
        d="M57.5244 105.689C58.3714 105.843 58.9984 106.096 58.9984 106.778C58.9984 107.636 58.1074 107.889 57.4034 107.889C56.4574 107.889 55.6434 107.537 55.4674 106.371H53.9494C54.0924 108.087 55.3904 109.143 57.3484 109.143C58.9544 109.143 60.5824 108.34 60.5824 106.701C60.5824 105.051 59.1524 104.534 57.8544 104.303L56.8094 104.116C56.1714 103.995 55.6984 103.687 55.6984 103.126C55.6984 102.411 56.5124 102.136 57.2384 102.136C57.9864 102.136 58.8004 102.444 58.9214 103.379H60.4394C60.3624 101.85 58.9544 100.882 57.3044 100.882C55.8304 100.882 54.1254 101.586 54.1254 103.192C54.1254 104.578 55.2144 105.249 56.5124 105.502L57.5244 105.689Z"
        fill="#F3F3F3"
      />
      <path
        d="M62.5544 101.025V109H64.1274V106.195H65.3264C67.1634 106.195 68.7914 105.7 68.7914 103.665C68.7914 101.256 66.9214 101.025 65.2824 101.025H62.5544ZM65.3154 102.257C66.1734 102.257 67.1744 102.367 67.1744 103.676C67.1744 104.732 66.4044 104.974 65.4254 104.974H64.1274V102.257H65.3154Z"
        fill="#F3F3F3"
      />
      <path
        d="M71.8888 105.007C71.8888 103.137 72.9228 102.136 74.1658 102.136C75.4088 102.136 76.4428 103.137 76.4428 105.007C76.4428 106.877 75.4088 107.889 74.1658 107.889C72.9228 107.889 71.8888 106.877 71.8888 105.007ZM78.0708 105.007C78.0708 102.532 76.5418 100.882 74.1658 100.882C71.7898 100.882 70.2608 102.532 70.2608 105.007C70.2608 107.482 71.7898 109.143 74.1658 109.143C76.5418 109.143 78.0708 107.482 78.0708 105.007Z"
        fill="#F3F3F3"
      />
      <path
        d="M85.0133 109H86.7623L84.9913 105.546C85.9813 105.128 86.4323 104.358 86.4323 103.445C86.4323 101.773 85.4313 101.025 82.8023 101.025H80.1843V109H81.7573V105.876H83.0553H83.4293L85.0133 109ZM82.9783 102.257C84.0453 102.257 84.8153 102.532 84.8153 103.456C84.8153 104.237 84.2763 104.655 83.0553 104.655H81.7573V102.257H82.9783Z"
        fill="#F3F3F3"
      />
      <path
        d="M90.1424 109H91.7154V102.301H94.1794V101.025H87.6894V102.301H90.1424V109Z"
        fill="#F3F3F3"
      />
      <g clip-path="url(#clip2_332_47939)">
        <circle
          cx="61.5"
          cy="30"
          r="28.125"
          fill="url(#paint0_radial_332_47939)"
        />
        <circle
          cx="61.5"
          cy="30"
          r="28.125"
          fill="url(#paint1_radial_332_47939)"
        />
        <path
          d="M61.5 0C44.9315 0 31.5 13.4315 31.5 30C31.5 46.5685 44.9315 60 61.5 60C78.0685 60 91.5 46.5685 91.5 30C91.5 13.4315 78.0685 0 61.5 0ZM60.3397 11.4576C61.1729 11.0494 62.0508 11.0774 62.8588 11.5359C65.6603 13.1323 68.4534 14.7428 71.2325 16.37C72.1272 16.8956 72.5857 17.7372 72.5885 18.7717C72.6053 22.3979 72.5997 26.0214 72.5885 29.6477C72.5885 29.7819 72.5019 29.9776 72.3928 30.0419C71.3164 30.685 70.226 31.3029 69.0433 31.9851V31.4147C69.0433 27.685 69.0322 23.9581 69.0517 20.2283C69.0545 19.5126 68.8085 19.0513 68.1738 18.6906C64.9222 16.8425 61.6873 14.9609 58.4469 13.0904C58.3071 13.0093 58.1701 12.9226 57.9576 12.794C58.7908 12.3215 59.5401 11.8462 60.3341 11.4576H60.3397ZM59.7442 48.5564C59.5624 48.4641 59.4282 48.3998 59.2968 48.3243C55.0051 45.8499 50.719 43.3588 46.4133 40.904C45.2055 40.2162 44.6547 39.2349 44.6687 37.8565C44.6938 34.9264 44.6855 31.9963 44.6715 29.0634C44.6659 27.7409 45.2027 26.7819 46.3658 26.1221C49.3882 24.4026 52.3938 22.658 55.3993 20.9105C55.6594 20.7596 55.8495 20.7344 56.1207 20.8966C57.158 21.52 58.2148 22.1156 59.3192 22.753C59.1095 22.8788 58.9501 22.9739 58.788 23.069C55.5335 24.9478 52.2847 26.8322 49.0219 28.6999C48.4879 29.0047 48.239 29.4017 48.2446 30.0224C48.2614 32.3318 48.2642 34.6412 48.2446 36.9506C48.239 37.5881 48.4935 37.9935 49.0415 38.3066C52.4832 40.2749 55.911 42.2656 59.35 44.2395C59.6407 44.4073 59.7637 44.5806 59.7582 44.9273C59.733 46.11 59.7498 47.2954 59.7498 48.5592L59.7442 48.5564ZM59.7442 41.9413C59.445 41.7707 59.2297 41.6505 59.0144 41.5247C56.2856 39.9506 53.5596 38.3709 50.8253 36.808C50.5289 36.6403 50.4199 36.4585 50.4226 36.1146C50.4422 34.3392 50.4338 32.5638 50.4282 30.7884C50.4282 30.548 50.4646 30.383 50.7022 30.2488C51.7088 29.6869 52.7041 29.0997 53.7022 28.5266C53.7749 28.4846 53.8532 28.4539 53.9846 28.3896V30.383C53.9846 31.4623 54.0014 32.5443 53.979 33.6235C53.9651 34.2386 54.2027 34.6552 54.7395 34.9571C56.2856 35.8294 57.8122 36.7353 59.3583 37.6048C59.6631 37.7754 59.7554 37.9655 59.7498 38.301C59.7302 39.4809 59.7414 40.6636 59.7414 41.9385L59.7442 41.9413ZM56.5932 18.6375C56.0144 18.2964 55.5196 18.2992 54.9408 18.6375C51.6976 20.5331 48.4404 22.4035 45.1859 24.2824C45.0489 24.3635 44.9063 24.4362 44.6631 24.5676C44.7498 23.3318 44.4842 22.1659 44.9063 21.0363C45.1356 20.4185 45.5662 19.9543 46.1365 19.6244C48.8514 18.0559 51.5634 16.4846 54.2838 14.9245C55.2763 14.3541 56.2884 14.3681 57.281 14.9413C60.3705 16.7195 63.4571 18.5033 66.5382 20.2926C66.6696 20.3681 66.8346 20.5387 66.8346 20.6673C66.8569 21.9366 66.8486 23.2088 66.8486 24.5704C65.7274 23.9245 64.6929 23.3262 63.6584 22.7279C61.3015 21.3663 58.939 20.0186 56.5932 18.6375ZM78.3033 38.5974C78.2223 39.5955 77.6379 40.3029 76.774 40.8006C73.4664 42.7018 70.1617 44.6142 66.8569 46.521C65.8197 47.1193 64.7824 47.7176 63.7423 48.3159C63.6165 48.3886 63.4879 48.4501 63.3173 48.5396C63.3061 48.3663 63.2922 48.2404 63.2922 48.1146C63.2922 47.0186 63.2978 45.9254 63.2866 44.8294C63.2866 44.5806 63.3453 44.4296 63.5746 44.2982C68.3947 41.5247 73.212 38.7428 78.0266 35.9637C78.0993 35.9217 78.1803 35.8882 78.3173 35.8239C78.3173 36.7968 78.3732 37.7027 78.3033 38.5974ZM78.3285 31.6971C78.3201 32.8322 77.7078 33.6291 76.7377 34.1883C72.9688 36.3551 69.2027 38.5331 65.4366 40.7083C64.7488 41.1053 64.0582 41.4995 63.3201 41.9245C63.3089 41.7372 63.295 41.6142 63.295 41.4883C63.295 40.4091 63.3062 39.3271 63.2866 38.2479C63.281 37.9404 63.3844 37.7782 63.65 37.6244C67.075 35.6589 70.4888 33.671 73.9194 31.7167C74.5289 31.37 74.7973 30.9422 74.7917 30.2265C74.7665 26.4967 74.7805 22.767 74.7805 19.0373V18.3858C75.6752 18.9254 76.514 19.37 77.2801 19.9124C77.979 20.4073 78.3313 21.1566 78.3341 22.0205C78.3453 25.247 78.3537 28.4734 78.3313 31.6999L78.3285 31.6971Z"
          fill="#131313"
        />
        <path
          fill-rule="evenodd"
          clip-rule="evenodd"
          d="M61.5 0C44.9315 0 31.5 13.4315 31.5 30C31.5 46.5685 44.9315 60 61.5 60C78.0685 60 91.5 46.5685 91.5 30C91.5 13.4315 78.0685 0 61.5 0ZM61.5 2.5C46.3122 2.5 34 14.8122 34 30C34 45.1878 46.3122 57.5 61.5 57.5C76.6878 57.5 89 45.1878 89 30C89 14.8122 76.6878 2.5 61.5 2.5Z"
          fill="url(#paint2_radial_332_47939)"
        />
        <path
          fill-rule="evenodd"
          clip-rule="evenodd"
          d="M61.5 0C44.9315 0 31.5 13.4315 31.5 30C31.5 46.5685 44.9315 60 61.5 60C78.0685 60 91.5 46.5685 91.5 30C91.5 13.4315 78.0685 0 61.5 0ZM61.5 2.5C46.3122 2.5 34 14.8122 34 30C34 45.1878 46.3122 57.5 61.5 57.5C76.6878 57.5 89 45.1878 89 30C89 14.8122 76.6878 2.5 61.5 2.5Z"
          fill="url(#paint3_radial_332_47939)"
        />
      </g>
    </g>
    <defs>
      <radialGradient
        id="paint0_radial_332_47939"
        cx="0"
        cy="0"
        r="1"
        gradientUnits="userSpaceOnUse"
        gradientTransform="translate(48.3053 16.7373) rotate(44.9817) scale(58.4359 123.929)"
      >
        <stop stop-color="#A3EEF8" />
        <stop offset="0.177083" stop-color="#A4DCF5" />
        <stop offset="0.380208" stop-color="#A6AEEC" />
        <stop offset="1" stop-color="#ECBEE1" />
      </radialGradient>
      <radialGradient
        id="paint1_radial_332_47939"
        cx="0"
        cy="0"
        r="1"
        gradientUnits="userSpaceOnUse"
        gradientTransform="translate(63.9394 54.6335) rotate(84.265) scale(30.2672 57.9018)"
      >
        <stop stop-color="#FCF5EE" />
        <stop offset="0.715135" stop-color="#ECBEE1" stop-opacity="0" />
      </radialGradient>
      <radialGradient
        id="paint2_radial_332_47939"
        cx="0"
        cy="0"
        r="1"
        gradientUnits="userSpaceOnUse"
        gradientTransform="translate(47.4257 15.8532) rotate(44.9817) scale(62.3316 132.191)"
      >
        <stop stop-color="#A3EEF8" />
        <stop offset="0.177083" stop-color="#A4DCF5" />
        <stop offset="0.380208" stop-color="#A6AEEC" />
        <stop offset="1" stop-color="#ECBEE1" />
      </radialGradient>
      <radialGradient
        id="paint3_radial_332_47939"
        cx="0"
        cy="0"
        r="1"
        gradientUnits="userSpaceOnUse"
        gradientTransform="translate(64.102 56.2758) rotate(84.265) scale(32.2851 61.7619)"
      >
        <stop stop-color="#FCF5EE" />
        <stop offset="0.715135" stop-color="#ECBEE1" stop-opacity="0" />
      </radialGradient>
      <clipPath id="clip0_332_47939">
        <rect
          width="123"
          height="112"
          fill="white"
          transform="translate(0.5)"
        />
      </clipPath>
      <clipPath id="clip1_332_47939">
        <rect
          width="123"
          height="19"
          fill="white"
          transform="translate(0.5 75)"
        />
      </clipPath>
      <clipPath id="clip2_332_47939">
        <rect
          width="60"
          height="60"
          fill="white"
          transform="translate(31.5)"
        />
      </clipPath>
    </defs>
  </svg>
`,ed=()=>`
    <button
      id="${er}"
      style="
        background: #f3f3f326 !important;
        border: none !important;
        border-radius: 50% !important;
        width: 48px !important;
        height: 48px !important;
        position: absolute !important;
        top: 40px !important;
        right: 40px !important;
        cursor: pointer !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
      "
    >
      ${en}
    </button>
  `,el=()=>`
    <div
      style="
        color: #e01a3d !important;
        display: flex !important;
        align-items: center !important;
        gap: 4px !important;
        margin-bottom: 10px !important;
      "
    >
      ${es}
      Pop-up blocked
    </div>
    <p style="
        color: #b6b6b6 !important;
        text-align: center !important;
        margin: 0 !important;
      "
    >
      Please try again below.<br />
      If the problem continues, adjust your<br />
      browser settings.
    </p>
  `,ec=()=>`
    <p style="
        color: #b6b6b6 !important;
        text-align: center !important;
        margin: 0 !important;
      "
    >
      Secure pop-up not showing?<br />We'll help you re-launch
    </p>
  `,eu=()=>`
    <button
      id="${ei}"
      style="
        margin-top: 27px !important;
        color: #f3f3f3 !important;
        background: transparent !important;
        padding: 12px 24px !important;
        border-radius: 30px !important;
        border: 2px solid #f3f3f3 !important;
        font-size: 1em !important;
        font-weight: 500 !important;
        cursor: pointer !important;
      "
    >
      Try again
    </button>
  `,ep=e=>`
    <div
      id="${ea}"
      style="
        position: fixed !important;
        top: 0 !important;
        left: 0 !important;
        width: 100% !important;
        height: 100% !important;
        background: rgba(13, 13, 13, 0.48) !important;
        backdrop-filter: blur(28px) !important;
        -webkit-backdrop-filter: blur(28px) !important;
        display: flex !important;
        flex-direction: column !important;
        justify-content: center !important;
        align-items: center !important;
        font-size: 16px !important;
        line-height: 1.5 !important;
        font-family: Roboto !important;
        font-style: normal !important;
        font-weight: 400 !important;
        font-feature-settings: 'clig' off, 'liga' off !important;
        z-index: 2147483647 !important;
      "
    >
      ${ed()}
      <div
        style="
          display: flex !important;
          flex-direction: column !important;
          align-items: center !important;
          max-width: 400px !important;
        "
      >
        ${eo}
        ${e}
        ${eu()}
      </div>
    </div>
  `;function e_({id:e,href:t,rel:a,crossOrigin:r}){let i=`${ea}-${e}`;if(!document.getElementById(i)){let e=document.createElement("link");e.id=i,e.href=t,a&&(e.rel=a),r&&(e.crossOrigin=r),document.head.appendChild(e)}}let eh=()=>ep(el()),eg=()=>ep(ec());class eE{disableGenericPopupOverlay;disableBlockedPopupOverlay;overlay;isBlockedOverlay;tryAgainListener;onCloseListener;constructor(e,t=!1){this.disableBlockedPopupOverlay=e.disableBlockedPopupOverlay||!1,this.disableGenericPopupOverlay=e.disableGenericPopupOverlay||!1,this.isBlockedOverlay=t}append(e,t){this.shouldAppendOverlay()&&(this.appendOverlay(),this.updateTryAgainButton(e),this.updateCloseButton(t))}update(e){this.updateTryAgainButton(e)}remove(){this.overlay&&this.overlay.remove()}shouldAppendOverlay(){return(!this.disableGenericPopupOverlay||!this.disableBlockedPopupOverlay)&&(!this.disableGenericPopupOverlay||!!this.isBlockedOverlay)&&(!this.disableBlockedPopupOverlay||!this.isBlockedOverlay)}appendOverlay(){if(!this.overlay){e_({id:"link-googleapis",href:"https://fonts.googleapis.com"}),e_({id:"link-gstatic",href:"https://fonts.gstatic.com",crossOrigin:"anonymous"}),e_({id:"link-roboto",href:"https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,400;0,500;0,700;1,400;1,500;1,700&display=swap",rel:"stylesheet"});let e=document.createElement("div");e.innerHTML=this.isBlockedOverlay?eh():eg(),document.body.insertAdjacentElement("beforeend",e),this.overlay=e}}updateTryAgainButton(e){let t=document.getElementById(ei);t&&(this.tryAgainListener&&t.removeEventListener("click",this.tryAgainListener),this.tryAgainListener=e,t.addEventListener("click",e))}updateCloseButton(e){let t=document.getElementById(er);t&&(this.onCloseListener&&t.removeEventListener("click",this.onCloseListener),this.onCloseListener=e,t.addEventListener("click",e))}}class em{storage;constructor(e,t){this.storage=v.createInstance({name:e,driver:t})}get length(){return this.storage.length()}clear(){return this.storage.clear()}getItem(e){return this.storage.getItem(e)}key(e){return this.storage.key(e)}async removeItem(e){await this.storage.removeItem(e)}async setItem(e,t){await this.storage.setItem(e,t)}}let eR={headers:{"Content-Type":"application/x-www-form-urlencoded"}},eC="/v2/logout",ef=e=>{let t;let{authenticationDomain:a,oidcConfiguration:r}=e;t=e.crossSdkBridgeEnabled?new em("ImmutableSDKPassport",v.INDEXEDDB):"undefined"!=typeof window?window.localStorage:new T.j_;let i=new T.bA({store:t}),n=new URL(eC,a.replace(/^(?:https?:\/\/)?(.*)/,"https://$1"));n.searchParams.set("client_id",r.clientId),r.logoutRedirectUri&&n.searchParams.set("returnTo",r.logoutRedirectUri);let s={authority:a,redirect_uri:r.redirectUri,popup_redirect_uri:r.redirectUri,client_id:r.clientId,metadata:{authorization_endpoint:`${a}/authorize`,token_endpoint:`${a}/oauth/token`,userinfo_endpoint:`${a}/userinfo`,end_session_endpoint:n.toString()},mergeClaims:!0,automaticSilentRenew:!1,scope:r.scope,userStore:i};return r.audience&&(s.extraQueryParams={audience:r.audience}),s};function ey(e){return e.toString("base64").replace(/\+/g,"-").replace(/\//g,"_").replace(/=/g,"")}class ew{userManager;deviceCredentialsManager;config;logoutMode;refreshingPromise=null;constructor(e){this.config=e,this.userManager=new T.ws(ef(e)),this.deviceCredentialsManager=new J,this.logoutMode=e.oidcConfiguration.logoutMode||"redirect"}static mapOidcUserToDomainModel=e=>{let t;e.id_token&&(t=A.Z(e.id_token)?.passport);let a={expired:e.expired,idToken:e.id_token,accessToken:e.access_token,refreshToken:e.refresh_token,profile:{sub:e.profile.sub,email:e.profile.email,nickname:e.profile.nickname}};return t?.imx_eth_address&&(a.imx={ethAddress:t.imx_eth_address,starkAddress:t.imx_stark_address,userAdminAddress:t.imx_user_admin_address}),t?.zkevm_eth_address&&(a.zkEvm={ethAddress:t?.zkevm_eth_address,userAdminAddress:t?.zkevm_user_admin_address}),a};static mapDeviceTokenResponseToOidcUser=e=>{let t=(0,A.Z)(e.id_token);return new T.n5({id_token:e.id_token,access_token:e.access_token,refresh_token:e.refresh_token,token_type:e.token_type,profile:{sub:t.sub,iss:t.iss,aud:t.aud,exp:t.exp,iat:t.iat,email:t.email,nickname:t.nickname,passport:t.passport}})};async login(e){return q(async()=>{let t="passportLoginPrompt",a=async()=>this.userManager.signinPopup({extraQueryParams:{...this.userManager.settings?.extraQueryParams??{},rid:(0,w.g)(w.D.RUNTIME_ID)||"",third_party_a_id:e||""},popupWindowFeatures:{width:410,height:450},popupWindowTarget:t});return new Promise((e,r)=>{a().then(t=>{e(ew.mapOidcUserToDomainModel(t))}).catch(i=>{if(!(i instanceof Error)||"Attempted to navigate on a disposed window"!==i.message){r(i);return}let n=!1,s=new eE(this.config.popupOverlayOptions,!0);s.append(async()=>{try{if(n)window.open("",t);else{n=!0;let t=await a();s.remove(),e(ew.mapOidcUserToDomainModel(t))}}catch(e){s.remove(),r(e)}},()=>{s.remove(),r(Error("Popup closed by user"))})})})},c.AUTHENTICATION_ERROR)}async getUserOrLogin(){let e=null;try{e=await this.getUser()}catch(e){Y.warn("Failed to retrieve a cached user session",e)}return e||this.login()}async loginCallback(){return q(async()=>{await this.userManager.signinCallback()},c.AUTHENTICATION_ERROR)}async loginWithDeviceFlow(e){return q(async()=>{let t=await C.default.post(`${this.config.authenticationDomain}/oauth/device/code`,{client_id:this.config.oidcConfiguration.clientId,scope:this.config.oidcConfiguration.scope,audience:this.config.oidcConfiguration.audience},eR),a=(0,w.g)(w.D.RUNTIME_ID);return{code:t.data.user_code,deviceCode:t.data.device_code,url:`${t.data.verification_uri_complete}${a?`&rid=${a}`:""}${e?`&third_party_a_id=${e}`:""}`,interval:t.data.interval}},c.AUTHENTICATION_ERROR)}async loginWithDeviceFlowCallback(e,t,a){return q(async()=>{let r=Date.now();for(;;){if(null!=a&&Date.now()-r>a)throw Error("Timed out");await function(e){return new Promise(t=>{setTimeout(t,e)})}(1e3*t);try{let t=await this.getDeviceFlowToken(e),a=ew.mapDeviceTokenResponseToOidcUser(t),r=ew.mapOidcUserToDomainModel(a);return await this.userManager.storeUser(a),r}catch(e){if(C.default.isAxiosError(e))switch((e.response?.data).error){case"authorization_pending":case"slow_down":break;case"expired_token":throw Error("Token expired, please log in again");case"access_denied":throw Error("User denied access");default:throw Error("Error getting token")}else throw e}}throw Error("Failed to get credentials")},c.AUTHENTICATION_ERROR)}async getDeviceFlowToken(e){return(await C.default.post(`${this.config.authenticationDomain}/oauth/token`,{client_id:this.config.oidcConfiguration.clientId,grant_type:"urn:ietf:params:oauth:grant-type:device_code",device_code:e},eR)).data}getPKCEAuthorizationUrl(){let e=ey(O.randomBytes(32)),t=ey(O.createHash("sha256").update(e).digest()),a=ey(O.randomBytes(32)),{redirectUri:r,scope:i,audience:n,clientId:s}=this.config.oidcConfiguration;this.deviceCredentialsManager.savePKCEData({state:a,verifier:e});let o=new URL("/authorize",this.config.authenticationDomain);return o.searchParams.set("response_type","code"),o.searchParams.set("code_challenge",t),o.searchParams.set("code_challenge_method","S256"),o.searchParams.set("client_id",s),o.searchParams.set("redirect_uri",r),o.searchParams.set("state",a),i&&o.searchParams.set("scope",i),n&&o.searchParams.set("audience",n),o.toString()}async loginWithPKCEFlowCallback(e,t){return q(async()=>{let a=this.deviceCredentialsManager.getPKCEData();if(!a)throw Error("No code verifier or state for PKCE");if(t!==a.state)throw Error("Provided state does not match stored state");let r=await this.getPKCEToken(e,a.verifier),i=ew.mapDeviceTokenResponseToOidcUser(r),n=ew.mapOidcUserToDomainModel(i);return await this.userManager.storeUser(i),n},c.AUTHENTICATION_ERROR)}async getPKCEToken(e,t){return(await C.default.post(`${this.config.authenticationDomain}/oauth/token`,{client_id:this.config.oidcConfiguration.clientId,grant_type:"authorization_code",code_verifier:t,code:e,redirect_uri:this.config.oidcConfiguration.redirectUri},eR)).data}async logout(){return q(async()=>"silent"===this.logoutMode?this.userManager.signoutSilent():this.userManager.signoutRedirect(),c.LOGOUT_ERROR)}async logoutSilentCallback(e){return this.userManager.signoutSilentCallback(e)}async removeUser(){return this.userManager.removeUser()}async getDeviceFlowEndSessionEndpoint(){let{authenticationDomain:e,oidcConfiguration:t}=this.config,a=new URL(eC,e);return a.searchParams.set("client_id",t.clientId),t.logoutRedirectUri&&a.searchParams.set("returnTo",t.logoutRedirectUri),a.toString()}forceUserRefreshInBackground(){this.refreshTokenAndUpdatePromise().catch(e=>{Y.warn("Failed to refresh user token",e)})}async forceUserRefresh(){return this.refreshTokenAndUpdatePromise()}async refreshTokenAndUpdatePromise(){return this.refreshingPromise||(this.refreshingPromise=new Promise(async(e,t)=>{try{let t=await this.userManager.signinSilent();if(t){e(ew.mapOidcUserToDomainModel(t));return}e(null)}catch(r){let e=c.AUTHENTICATION_ERROR,a="Failed to refresh token";r instanceof T.C3?e=c.SILENT_LOGIN_ERROR:r instanceof T.iQ?(e=c.NOT_LOGGED_IN_ERROR,a=`${r.message}: ${r.error_description}`):r instanceof Error&&(a=r.message),t(new X(a,e))}finally{this.refreshingPromise=null}})),this.refreshingPromise}async getUser(e=e=>!0){if(this.refreshingPromise){let t=await this.refreshingPromise;return t&&e(t)?t:null}let t=await this.userManager.getUser();if(!t)return null;if(!function(e){let{id_token:t,expired:a}=e;return!!a||function(e){if(!e)return!1;let t=(0,A.Z)(e),a=Math.floor(Date.now()/1e3);return t.exp<a}(t)}(t)){let a=ew.mapOidcUserToDomainModel(t);if(a&&e(a))return a}if(t.refresh_token){let t=await this.refreshTokenAndUpdatePromise();if(t&&e(t))return t}return null}async getUserZkEvm(){let e=await this.getUser(ee);if(!e)throw Error("Failed to obtain a User with the required ZkEvm attributes");return e}async getUserImx(){let e=await this.getUser(et);if(!e)throw Error("Failed to obtain a User with the required IMX attributes");return e}}let eT=(e,t)=>e().then(t),eO=e=>eT(()=>new Promise(e=>{let t=()=>{"complete"===window.document.readyState&&(e(),window.document.removeEventListener("readystatechange",t))};window.document.addEventListener("readystatechange",t),"complete"===window.document.readyState&&(e(),window.document.removeEventListener("readystatechange",t))}),e),eA=async(e,t)=>{let a=(0,w.b)("passport",t);try{return await e(a)}catch(e){throw e instanceof Error&&(0,w.c)("passport",t,e),a.addEvent("errored"),e}finally{a.addEvent("End")}},ev=async e=>q(async()=>{let t=await (0,y.g)(e);return(0,y.a)(t)},c.WALLET_CONNECTION_ERROR);async function eI({user:e,starkSigner:t,request:a,exchangesApi:r}){return q(async()=>{let{ethAddress:i}=e.imx,n=a.amount,s=await r.getExchangeSignableTransfer({id:a.transactionID,getSignableTransferRequest:{sender:i,token:(0,y.c)(a),amount:n,receiver:a.receiver}}),o=await t.getAddress(),{payload_hash:d}=s.data,l=await t.signMessage(d),c={sender_stark_key:s.data.sender_stark_key||o,sender_vault_id:s.data.sender_vault_id,receiver_stark_key:s.data.receiver_stark_key,receiver_vault_id:s.data.receiver_vault_id,asset_id:s.data.asset_id,amount:s.data.amount,nonce:s.data.nonce,expiration_timestamp:s.data.expiration_timestamp,stark_signature:l},u={Authorization:`Bearer ${e.accessToken}`},p=await r.createExchangeTransfer({id:a.transactionID,createTransferRequest:c},{headers:u});return{sent_signature:p?.data.sent_signature,status:p?.data.status?.toString(),time:p?.data.time,transfer_id:p?.data.transfer_id}},c.EXCHANGE_TRANSFER_ERROR)}let eN="ERC721";async function ek({starkSigner:e,user:t,request:a,ordersApi:r,guardianClient:i}){return q(async()=>{let{ethAddress:n}=t.imx,s=a.sell.type===eN?"1":a.sell.amount,o=a.buy.type===eN?"1":a.buy.amount,d={Authorization:`Bearer ${t.accessToken}`},l={user:n,amount_buy:o,token_buy:(0,y.c)(a.buy),amount_sell:s,token_sell:(0,y.c)(a.sell),fees:a.fees,split_fees:!0,expiration_timestamp:a.expiration_timestamp},c=await r.getSignableOrder({getSignableOrderRequestV3:l},{headers:d});await i.evaluateImxTransaction({payloadHash:c.data.payload_hash});let{payload_hash:u}=c.data,p=await e.signMessage(u),_=c.data,h={createOrderRequest:{include_fees:!0,fees:a.fees,stark_signature:p,amount_buy:_.amount_buy,amount_sell:_.amount_sell,asset_id_buy:_.asset_id_buy,asset_id_sell:_.asset_id_sell,expiration_timestamp:_.expiration_timestamp,nonce:_.nonce,stark_key:_.stark_key,vault_id_buy:_.vault_id_buy,vault_id_sell:_.vault_id_sell}};return{...(await r.createOrderV3(h,{headers:d})).data}},c.CREATE_ORDER_ERROR)}async function eS({user:e,starkSigner:t,request:a,ordersApi:r,guardianClient:i}){return q(async()=>{let n={order_id:a.order_id},s={Authorization:`Bearer ${e.accessToken}`},o=await r.getSignableCancelOrderV3({getSignableCancelOrderRequest:n},{headers:s});await i.evaluateImxTransaction({payloadHash:o.data.payload_hash});let{payload_hash:d}=o.data,l=await t.signMessage(d),c=await r.cancelOrderV3({id:a.order_id.toString(),cancelOrderRequest:{order_id:a.order_id,stark_signature:l}},{headers:s});return{order_id:c.data.order_id,status:c.data.status}},c.CANCEL_ORDER_ERROR)}async function eL({ethSigner:e,starkSigner:t,imxApiClients:a},r){return q(async()=>{let[i,n]=await Promise.all([e.getAddress(),t.getAddress()]),{signable_message:s,payload_hash:o}=(await a.usersApi.getSignableRegistrationOffchain({getSignableRegistrationRequest:{ether_key:i,stark_key:n}})).data,[d,l]=await Promise.all([(0,y.s)(s,e),t.signMessage(o)]);return(await a.usersApi.registerPassportUserV2({authorization:`Bearer ${r}`,registerPassportUserRequest:{eth_signature:d,ether_key:i,stark_signature:l,stark_key:n}})).data},c.USER_REGISTRATION_ERROR)}async function eD({request:e,tradesApi:t,user:a,starkSigner:r,guardianClient:i}){return q(async()=>{let{ethAddress:n}=a.imx,s={expiration_timestamp:e.expiration_timestamp,fees:e.fees,order_id:e.order_id,user:n},o={Authorization:`Bearer ${a.accessToken}`},d=await t.getSignableTrade({getSignableTradeRequest:s},{headers:o});await i.evaluateImxTransaction({payloadHash:d.data.payload_hash});let{payload_hash:l}=d.data,c=await r.signMessage(l),{data:u}=d,p={createTradeRequest:{include_fees:!0,fees:e?.fees,stark_signature:c,order_id:e?.order_id,fee_info:u.fee_info,amount_buy:u.amount_buy,amount_sell:u.amount_sell,asset_id_buy:u.asset_id_buy,asset_id_sell:u.asset_id_sell,expiration_timestamp:u.expiration_timestamp,nonce:u.nonce,stark_key:u.stark_key,vault_id_buy:u.vault_id_buy,vault_id_sell:u.vault_id_sell}},{data:_}=await t.createTradeV3(p,{headers:o});return _},c.CREATE_TRADE_ERROR)}let eb="ERC721";async function ex({request:e,transfersApi:t,starkSigner:a,user:r,guardianClient:i}){return q(async()=>{let n=e.type===eb?"1":e.amount,s={sender:r.imx.ethAddress,token:(0,y.c)(e),amount:n,receiver:e.receiver},o={Authorization:`Bearer ${r.accessToken}`},d=await t.getSignableTransferV1({getSignableTransferRequest:s},{headers:o});await i.evaluateImxTransaction({payloadHash:d.data.payload_hash});let l=d.data,{payload_hash:c}=l,u=await a.signMessage(c),p=await a.getAddress(),_={sender_stark_key:l.sender_stark_key||p,sender_vault_id:l.sender_vault_id,receiver_stark_key:l.receiver_stark_key,receiver_vault_id:l.receiver_vault_id,asset_id:l.asset_id,amount:l.amount,nonce:l.nonce,expiration_timestamp:l.expiration_timestamp,stark_signature:u},{data:h}=await t.createTransferV1({createTransferRequest:_},{headers:o});return{sent_signature:h.sent_signature,status:h.status?.toString(),time:h.time,transfer_id:h.transfer_id}},c.TRANSFER_ERROR)}async function eU({user:e,starkSigner:t,request:a,transfersApi:r,guardianClient:i}){return q(async()=>{let{ethAddress:n}=e.imx,s=a.map(e=>({amount:"1",token:(0,y.c)({type:eb,tokenId:e.tokenId,tokenAddress:e.tokenAddress}),receiver:e.receiver})),o={Authorization:`Bearer ${e.accessToken}`},d=await r.getSignableTransfer({getSignableTransferRequestV2:{sender_ether_key:n,signable_requests:s}},{headers:o});await i.evaluateImxTransaction({payloadHash:d.data.signable_responses[0]?.payload_hash});let l=await Promise.all(d.data.signable_responses.map(async e=>{let a=await t.signMessage(e.payload_hash);return{sender_vault_id:e.sender_vault_id,receiver_stark_key:e.receiver_stark_key,receiver_vault_id:e.receiver_vault_id,asset_id:e.asset_id,amount:e.amount,nonce:e.nonce,expiration_timestamp:e.expiration_timestamp,stark_signature:a}})),c={sender_stark_key:d.data.sender_stark_key,requests:l},u=await r.createTransfer({createTransferRequestV2:c},{headers:o});return{transfer_ids:u?.data.transfer_ids}},c.TRANSFER_ERROR)}let eM=e=>new Promise(t=>{setTimeout(()=>t(),e)}),eP=async(e,t)=>{let{retries:a=3,interval:r=1e3,finalErr:i=Error("Retry failed"),finallyFn:n=()=>{}}=t||{};try{return await e()}catch(t){if(a<=0)return Promise.reject(i);return await eM(r),eP(e,{retries:a-1,finalErr:i,finallyFn:n})}finally{a<=0&&n()}};async function eF(e){await eP(async()=>{let t=await e.forceUserRefresh();return t?.imx?t:Promise.reject(Error("user wallet addresses not exist"))})}async function eH(e,t,a,r,i){return q(async()=>{try{let n=await eL({ethSigner:e,starkSigner:t,imxApiClients:i},a.accessToken);return await eF(r),n}catch(e){if(C.default.isAxiosError(e)&&e.response?.status===409)return await eF(r),{tx_hash:""};throw e}},c.USER_REGISTRATION_ERROR)}class eV{authManager;immutableXClient;guardianClient;imxApiClients;magicAdapter;signers;signerInitialisationError;constructor({authManager:e,immutableXClient:t,passportEventEmitter:a,magicAdapter:r,imxApiClients:i,guardianClient:n}){this.authManager=e,this.immutableXClient=t,this.magicAdapter=r,this.imxApiClients=i,this.guardianClient=n,this.#e(),a.on(u.LOGGED_OUT,this.handleLogout)}handleLogout=()=>{this.signers=void 0};#e(){let e=async()=>{let e=await this.authManager.getUser(),t=await this.magicAdapter.login(e.idToken),a=new k.Q(t).getSigner(),r=await ev(a);return{ethSigner:a,starkSigner:r}};this.signers=new Promise(async t=>{try{t(await e())}catch(e){this.signerInitialisationError=e,t(void 0)}})}async #t(){let e=await this.authManager.getUser();if(!e||!this.signers)throw new X("User has been logged out",c.NOT_LOGGED_IN_ERROR);return e}async #a(){let e=await this.signers;if(void 0===e){if(void 0!==this.signerInitialisationError)throw this.signerInitialisationError;throw Error("Signers failed to initialise")}return e}async #r(){let[e,t]=await Promise.all([this.#t(),this.#a()]);if(!et(e))throw new X("User has not been registered with StarkEx",c.USER_NOT_REGISTERED_ERROR);return{user:e,starkSigner:t.starkSigner,ethSigner:t.ethSigner}}async transfer(e){return eA(()=>this.guardianClient.withDefaultConfirmationScreenTask(async()=>{let{user:t,starkSigner:a}=await this.#r();return ex({request:e,user:t,starkSigner:a,transfersApi:this.immutableXClient.transfersApi,guardianClient:this.guardianClient})})(),"imxTransfer")}async registerOffchain(){return eA(async()=>{let[e,t]=await Promise.all([this.#t(),this.#a()]);return await eH(t.ethSigner,t.starkSigner,e,this.authManager,this.imxApiClients)},"imxRegisterOffchain")}async isRegisteredOffchain(){return eA(async()=>!!(await this.#t()).imx,"imxIsRegisteredOffchain")}isRegisteredOnchain(){throw new X("Operation not supported",c.OPERATION_NOT_SUPPORTED_ERROR)}async createOrder(e){return eA(()=>this.guardianClient.withDefaultConfirmationScreenTask(async()=>{let{user:t,starkSigner:a}=await this.#r();return ek({request:e,user:t,starkSigner:a,ordersApi:this.immutableXClient.ordersApi,guardianClient:this.guardianClient})})(),"imxCreateOrder")}async cancelOrder(e){return eA(()=>this.guardianClient.withDefaultConfirmationScreenTask(async()=>{let{user:t,starkSigner:a}=await this.#r();return eS({request:e,user:t,starkSigner:a,ordersApi:this.immutableXClient.ordersApi,guardianClient:this.guardianClient})})(),"imxCancelOrder")}async createTrade(e){return eA(()=>this.guardianClient.withDefaultConfirmationScreenTask(async()=>{let{user:t,starkSigner:a}=await this.#r();return eD({request:e,user:t,starkSigner:a,tradesApi:this.immutableXClient.tradesApi,guardianClient:this.guardianClient})})(),"imxCreateTrade")}async batchNftTransfer(e){return eA(()=>this.guardianClient.withConfirmationScreenTask({width:480,height:784})(async()=>{let{user:t,starkSigner:a}=await this.#r();return eU({request:e,user:t,starkSigner:a,transfersApi:this.immutableXClient.transfersApi,guardianClient:this.guardianClient})})(),"imxBatchNftTransfer")}async exchangeTransfer(e){return eA(async()=>{let{user:t,starkSigner:a}=await this.#r();return eI({request:e,user:t,starkSigner:a,exchangesApi:this.immutableXClient.exchangeApi})},"imxExchangeTransfer")}deposit(e){throw new X("Operation not supported",c.OPERATION_NOT_SUPPORTED_ERROR)}prepareWithdrawal(e){throw new X("Operation not supported",c.OPERATION_NOT_SUPPORTED_ERROR)}completeWithdrawal(e,t){throw new X("Operation not supported",c.OPERATION_NOT_SUPPORTED_ERROR)}async getAddress(){return eA(async()=>{let e=await this.#t();if(!et(e))throw new X("User has not been registered with StarkEx",c.USER_NOT_REGISTERED_ERROR);return Promise.resolve(e.imx.ethAddress)},"imxGetAddress")}}let e$=(e,t,a)=>{let r=t.map(t=>!e[t]&&t).filter(e=>e).join(", ");if(""!==r)throw new X(a?`${a} - ${r} cannot be null`:`${r} cannot be null`,c.INVALID_CONFIGURATION)};(p||(p={})).CONFIRMATION_START="confirmation_start",(s=_||(_={})).CONFIRMATION_WINDOW_READY="confirmation_window_ready",s.TRANSACTION_CONFIRMED="transaction_confirmed",s.TRANSACTION_ERROR="transaction_error",s.TRANSACTION_REJECTED="transaction_rejected",s.MESSAGE_CONFIRMED="message_confirmed",s.MESSAGE_ERROR="message_error",s.MESSAGE_REJECTED="message_rejected";let eG="imx_passport_confirmation",eZ=({url:e,title:t,width:a,height:r})=>{let i=Math.max(0,Math.round(window.screenX+(window.outerWidth-a)/2)),n=Math.max(0,Math.round(window.screenY+(window.outerHeight-r)/2)),s=window.open(e,t,`
      scrollbars=yes,
      width=${a}, 
      height=${r}, 
      top=${n}, 
      left=${i}
     `);if(!s)throw Error("Failed to open confirmation screen");return s.focus(),s},eB="Confirm this transaction";(o=h||(h={})).PENDING="PENDING",o.SUBMITTED="SUBMITTED",o.SUCCESSFUL="SUCCESSFUL",o.REVERTED="REVERTED",o.FAILED="FAILED",o.CANCELLED="CANCELLED",(g||(g={})).ACCOUNTS_CHANGED="accountsChanged";let eW=`tuple(
  bool delegateCall,
  bool revertOnError,
  uint256 gasLimit,
  address target,
  uint256 value,
  bytes data
)[]`,eK=e=>e.map(e=>({delegateCall:!0===e.delegateCall,revertOnError:!0===e.revertOnError,gasLimit:e.gasLimit??S._Y,target:e.to??L.d,value:e.value??S._Y,data:e.data??[]})),ez=(e,t)=>{let a=D.$.encode(["uint256",eW],[e,t]);return b.keccak256(a)},eX=e=>D.$.encode([eW],[e]),eq=async(e,t)=>{try{let a=new x.CH(t,B.Y.mainModule.abi,e),r=await a.nonce();if(r instanceof U.O$)return r}catch(e){if(e instanceof Error&&"code"in e&&e.code===M.ErrorCode.CALL_EXCEPTION)return U.O$.from(0);throw e}throw Error("Unexpected result from contract.nonce() call.")},ej=(e,t,a)=>P.pack(["string","uint256","address","bytes32"],["\x19\x01",e,t,a]),eQ=async(e,t,a,r,i)=>{let n=eK(e),s=ej(a,r,ez(t,n)),o=b.keccak256(s),d=F.arrayify(o),l=performance.now(),c=await i.signMessage(d);(0,w.d)("passport","magicSignMessageGetSignedMetaTransactions",Math.round(performance.now()-l));let u=`${c}02`,p=W.v1.signature.encodeSignature({version:1,threshold:1,signers:[{isDynamic:!1,unrecovered:!0,weight:1,signature:u}]}),_=new H.vU(B.Y.mainModule.abi);return _.encodeFunctionData(_.getFunction("execute"),[n,t,p])},eJ=e=>{let t=`0x0000${e}`;return W.v1.signature.decodeSignature(t)},eY=(e,t,a)=>{let r=`${e}02`,{signers:i}=eJ(a),n=[...i,{isDynamic:!1,unrecovered:!0,weight:1,signature:r,address:t}].sort((e,t)=>{let a=U.O$.from(e.address),r=U.O$.from(t.address);return a.lte(r)?-1:a.eq(r)?0:1});return W.v1.signature.encodeSignature({version:1,threshold:2,signers:n})},e1=async(e,t,a,r,i)=>{let n={...e.types};delete n.EIP712Domain;let{_TypedDataEncoder:s}=V,o=ej(a,r,s.hash(e.domain,n,e.message)),d=b.keccak256(o),l=F.arrayify(d),c=performance.now(),u=await i.signMessage(l);return(0,w.d)("passport","magicSignMessageTypedData",Math.round(performance.now()-c)),eY(u,await i.getAddress(),t)},e3=async(e,t,a,r)=>{let i=ej(e,r,$.r(t)),n=b.keccak256(i),s=F.arrayify(n);return a.signMessage(s)},e0=e=>`eip155:${e}`;(d=E||(E={}))[d.USER_REJECTED_REQUEST=4001]="USER_REJECTED_REQUEST",d[d.UNAUTHORIZED=4100]="UNAUTHORIZED",d[d.UNSUPPORTED_METHOD=4200]="UNSUPPORTED_METHOD",d[d.DISCONNECTED=4900]="DISCONNECTED",(l=m||(m={}))[l.RPC_SERVER_ERROR=-32e3]="RPC_SERVER_ERROR",l[l.INVALID_REQUEST=-32600]="INVALID_REQUEST",l[l.METHOD_NOT_FOUND=-32601]="METHOD_NOT_FOUND",l[l.INVALID_PARAMS=-32602]="INVALID_PARAMS",l[l.INTERNAL_ERROR=-32603]="INTERNAL_ERROR",l[l.PARSE_ERROR=-32700]="PARSE_ERROR",l[l.TRANSACTION_REJECTED=-32003]="TRANSACTION_REJECTED";class e5 extends Error{message;code;constructor(e,t){super(t),this.message=t,this.code=e}}let e8="Transaction requires confirmation but this functionality is not supported in this environment. Please contact Immutable support if you need to enable this feature.",e4=e=>U.O$.from(e).toString(),e2=e=>{try{return e.map(e=>({delegateCall:!0===e.delegateCall,revertOnError:!0===e.revertOnError,gasLimit:e.gasLimit?e4(e.gasLimit):"0",target:e.to??L.d,value:e.value?e4(e.value):"0",data:e.data?e.data.toString():"0x"}))}catch(t){let e=t instanceof Error?t.message:String(t);throw new e5(m.INVALID_PARAMS,`Transaction failed to parsing: ${e}`)}},e6=async(e,t,a)=>{let r=eX(eK([e])),i=(await a.imGetFeeOptions(t,r)).find(e=>"IMX"===e.tokenSymbol);if(!i)throw Error("Failed to retrieve fees for IMX token");return i},e7=async(e,t,a,r)=>{if(!e.to)throw new e5(m.INVALID_PARAMS,'eth_sendTransaction requires a "to" field');let i={to:e.to,data:e.data,nonce:U.O$.from(0),value:e.value,revertOnError:!0},[n,s]=await Promise.all([eq(t,r),e6(i,r,a)]),o=[{...i,nonce:n}],d=U.O$.from(s.tokenPrice);return d.isZero()||o.push({nonce:n,to:s.recipientAddress,value:d,revertOnError:!0}),o},e9=async(e,t,a)=>{let r=async()=>{let a=await e.imGetTransactionByHash(t);if(a.status===h.PENDING)throw Error();return a},i=await eP(r,{retries:30,interval:1e3,finalErr:new e5(m.RPC_SERVER_ERROR,"transaction hash not generated in time")});if(a.addEvent("endRetrieveRelayerTransaction"),![h.SUBMITTED,h.SUCCESSFUL].includes(i.status)){let e=`Transaction failed to submit with status ${i.status}.`;throw i.statusMessage&&(e+=` Error message: ${i.statusMessage}`),new e5(m.RPC_SERVER_ERROR,e)}return i},te=async({transactionRequest:e,ethSigner:t,rpcProvider:a,guardianClient:r,relayerClient:i,zkEvmAddress:n,flow:s})=>{let{chainId:o}=await a.detectNetwork(),d=U.O$.from(o);s.addEvent("endDetectNetwork");let l=await e7(e,a,i,n);s.addEvent("endBuildMetaTransactions");let{nonce:c}=l[0];if(!c)throw Error("Failed to retrieve nonce from the smart wallet");let u=async()=>{await r.validateEVMTransaction({chainId:e0(o),nonce:e4(c),metaTransactions:l}),s.addEvent("endValidateEVMTransaction")},p=async()=>{let e=await eQ(l,c,d,n,t);return s.addEvent("endGetSignedMetaTransactions"),e},[,_]=await Promise.all([u(),p()]),h=await i.ethSendTransaction(n,_);return s.addEvent("endRelayerSendTransaction"),{signedTransactions:_,relayerId:h,nonce:c}},tt=["types","domain","primaryType","message"],ta=e=>tt.every(t=>t in e),tr=(e,t)=>{let a;if("string"==typeof e)try{a=JSON.parse(e)}catch(e){throw new e5(m.INVALID_PARAMS,`Failed to parse typed data JSON: ${e}`)}else if("object"==typeof e)a=e;else throw new e5(m.INVALID_PARAMS,`Invalid typed data argument: ${e}`);if(!ta(a))throw new e5(m.INVALID_PARAMS,`Invalid typed data argument. The following properties are required: ${tt.join(", ")}`);let r=a.domain?.chainId;if(r&&("string"==typeof r&&(r.startsWith("0x")?a.domain.chainId=parseInt(r,16):a.domain.chainId=parseInt(r,10)),a.domain.chainId!==t))throw new e5(m.INVALID_PARAMS,`Invalid chainId, expected ${t}`);return a},ti=e=>{if(!e)return e;try{let t=F.stripZeros(F.arrayify(e));return G.ZN(t)}catch(t){return e}},tn=async({params:e,ethSigner:t,zkEvmAddress:a,rpcProvider:r,guardianClient:i,relayerClient:n,flow:s})=>{let o=e[0],d=e[1];if(!d||!o)throw new e5(m.INVALID_PARAMS,"personal_sign requires an address and a message");if(d.toLowerCase()!==a.toLowerCase())throw new e5(m.INVALID_PARAMS,"personal_sign requires the signer to be the from address");let l=ti(o),{chainId:c}=await r.detectNetwork();s.addEvent("endDetectNetwork");let u=e3(U.O$.from(c),l,t,d);u.then(()=>s.addEvent("endEOASignature")),await i.evaluateERC191Message({chainID:c,payload:l}),s.addEvent("endEvaluateERC191Message");let[p,_]=await Promise.all([u,n.imSign(d,l)]);s.addEvent("endRelayerSign");let h=await t.getAddress();return s.addEvent("endGetEOAAddress"),eY(p,h,_)},ts=e=>{switch(e){case w.E.SANDBOX:return"https://api.sandbox.immutable.com";case w.E.PRODUCTION:return"https://api.immutable.com";default:throw Error("Environment not supported")}},to=e=>{r||(r=C.default.create({baseURL:ts(e)}))};async function td(e){if(!r)throw Error("Client not initialised");return r.get("/v1/sdk/session-activity/check",{params:e}).then(e=>e.data).catch(e=>{if(404!==e.response.status)throw e})}let{getItem:tl,setItem:tc}=w.u.localStorage,tu="sessionActivitySendCount",tp="sessionActivityDate",t_=0,th=0,tg=!1,tE=()=>{th=tl(tu)||0;let e=tl(tp),t=new Date().toISOString().split("T")[0];e&&e===t||(th=0),tc(tp,t),tc(tu,th)};tE();let tm=()=>{tE(),tc(tu,++th),t_=0},tR=async e=>new Promise(t=>{setTimeout(t,1e3*e)}),tC=async e=>{let t;let a=e.flow||(0,w.b)("passport","sendSessionActivity");if(tg){a.addEvent("Existing Delay Early Exit");return}tg=!0;let{sendTransaction:r,environment:i}=e;if(!r)throw Error("No sendTransaction function provided");if(!i)throw Error("No environment provided");to(i);let n=e.passportClient;if(!n)throw a.addEvent("No Passport Client ID"),Error("No Passport Client ID provided");let s=e.walletAddress;if(!s)throw a.addEvent("No Passport Wallet Address"),Error("No wallet address");try{if(a.addEvent("Fetching details"),t=await td({clientId:n,wallet:s,checkCount:t_,sendCount:th}),t_++,a.addEvent("Fetched details",{checkCount:t_}),!t){a.addEvent("No details found");return}}catch(e){throw a.addEvent("Failed to fetch details"),Error("Failed to get details",{cause:e})}if(t&&t.contractAddress&&t.functionName){let r=new H.vU([`function ${t.functionName}()`]).encodeFunctionData(t.functionName),i=t.contractAddress;try{a.addEvent("Start Sending Transaction");let t=await e.sendTransaction([{to:i,from:s,data:r}],a);tm(),a.addEvent("Transaction Sent",{tx:t})}catch(t){a.addEvent("Failed to send Transaction");let e=Error("Failed to send transaction",{cause:t});(0,w.c)("passport","sessionActivityError",e)}}t&&t.delay&&t.delay>0&&(a.addEvent("Delaying Transaction",{delay:t.delay}),await tR(t.delay),setTimeout(()=>{a.addEvent("Retrying after Delay"),tg=!1,tf({...e,flow:a})},0))},tf=e=>{var t;return((...e)=>{try{let t=tC(...e);if(t instanceof Promise)return t.catch(e=>void(e instanceof Error&&(0,w.c)("passport","sessionActivityError",e)));return t}catch(e){return e instanceof Error&&(0,w.c)("passport","sessionActivityError",e),t}})(e).then(()=>{tg=!1})};(0,K.Z)();let ty=e=>e.overrides?(0,f.c)({basePath:e.overrides.imxPublicApiDomain}):e.baseConfig.environment===w.E.SANDBOX?f.b.getSandbox():f.b.getProduction()}}]);