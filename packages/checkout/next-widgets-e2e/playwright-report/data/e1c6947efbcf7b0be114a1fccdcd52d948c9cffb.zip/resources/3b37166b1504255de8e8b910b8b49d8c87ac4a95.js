export { dC as WidgetsFactory } from './index-Ae2juTF3.js';
